package com.arabikey.keyboard

/** اقتراحات محلية بسيطة (بدون إنترنت). */
object Words {
    private val ar: List<String> = (
        "السلام عليكم ورحمة الله وبركاته وعليكم مرحبا مرحباً أهلا أهلاً وسهلا هلا والله وغلا كيف حالك " +
            "الحمد لله بخير شكرا شكراً جزيلا يعطيك العافية الله يعافيك إن شاء الله ماشاء الله بإذن الله " +
            "جزاك الله خيرا صباح الخير مساء الخير تصبح على خير مع السلامة في أمان الله نورت المكان أبشر " +
            "من عيوني تم طال عمرك الموعد القهوة قهوة اليوم غدا بكرة الآن لاحقا اتصل رسالة واتساب المنزل " +
            "البيت العمل الاجتماع المدرسة الجامعة المستشفى المطار السيارة الطريق الوقت الساعة الصباح " +
            "المساء الليل النهار الأسبوع الشهر السنة محمد رسول القرآن الكريم رمضان العيد مبارك كل عام " +
            "وأنتم بخير سعيد تهنئة تعازي صحيح خطأ نعم ربما ممكن أكيد طبعا تمام ممتاز رائع جميل حلو " +
            "حزين مشغول متعب جاهز قريب بعيد سريع بطيء كبير صغير جديد قديم ماذا لماذا متى أين هذا هذه " +
            "ذلك التي الذي إلى بعد قبل عند حتى لكن اشتقت أحبك الله يسلمك يسلمو الله يحفظك ان إن"
        ).split(" ").filter { it.isNotEmpty() }.distinct()

    private val en: List<String> = (
        "hello hi hey thanks thank you please welcome sorry good morning evening night how are what " +
            "when where why who the and for with this that have from your will can would could about " +
            "message call today tomorrow tonight okay yes sure great awesome love friend family work " +
            "home meeting see later soon again really maybe because before after"
        ).split(" ").filter { it.isNotEmpty() }.distinct()

    private val next: Map<String, List<String>> = mapOf(
        "السلام" to listOf("عليكم", "عليكم ورحمة الله وبركاته"),
        "وعليكم" to listOf("السلام", "السلام ورحمة الله"),
        "كيف" to listOf("حالك؟", "الحال؟", "أصبحت؟"),
        "إن" to listOf("شاء الله"),
        "ان" to listOf("شاء الله"),
        "ما" to listOf("شاء الله"),
        "جزاك" to listOf("الله خيرا"),
        "يعطيك" to listOf("العافية"),
        "صباح" to listOf("الخير", "النور"),
        "مساء" to listOf("الخير", "النور"),
        "شكرا" to listOf("لك", "جزيلا", "لك أخي"),
        "شكراً" to listOf("لك", "جزيلا", "لك أخي"),
        "مع" to listOf("السلامة"),
        "الحمد" to listOf("لله"),
        "how" to listOf("are", "is", "do"),
        "thank" to listOf("you"),
        "good" to listOf("morning", "night", "evening"),
    )

    private val defaultsAr = listOf("السلام عليكم", "شكراً", "إن شاء الله")
    private val defaultsEn = listOf("I", "The", "Thanks")

    private fun pad(list: List<String>): List<String> = (list + listOf("", "", "")).take(3)

    private fun norm(s: String): String = buildString {
        for (ch in s) {
            when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> append('ا')
                'ى' -> append('ي')
                else -> if (Character.getType(ch) != Character.NON_SPACING_MARK.toInt()) append(ch)
            }
        }
    }.lowercase()

    fun suggest(word: String, prev: String, arabic: Boolean): List<String> {
        if (word.isEmpty()) {
            val n = next[prev] ?: next[prev.lowercase()]
            return pad(n ?: if (arabic) defaultsAr else defaultsEn)
        }
        val w = norm(word)
        val pool = if (arabic) ar + en else en + ar
        val matches = pool
            .filter { norm(it).startsWith(w) && norm(it) != w }
            .sortedBy { it.length }
            .take(3)
        if (matches.isEmpty()) return listOf("", word, "")
        return pad(matches)
    }
}
