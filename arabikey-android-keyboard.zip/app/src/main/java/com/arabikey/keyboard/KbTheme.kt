package com.arabikey.keyboard

import android.graphics.Color

/** ثيمان فقط: أبيض ثلجي (snow) وأسود (black). */
data class KbTheme(
    val name: String,
    val bg: Int,
    val bar: Int,
    val key: Int,
    val keyPressed: Int,
    val action: Int,
    val actionPressed: Int,
    val text: Int,
    val muted: Int,
    val accent: Int,
    val onAccent: Int,
    val divider: Int,
) {
    companion object {
        val SNOW = KbTheme(
            name = "snow",
            bg = Color.parseColor("#F5F9FF"),
            bar = Color.parseColor("#FFFFFF"),
            key = Color.parseColor("#FFFFFF"),
            keyPressed = Color.parseColor("#DCE7F3"),
            action = Color.parseColor("#E3ECF6"),
            actionPressed = Color.parseColor("#C9D9EA"),
            text = Color.parseColor("#0F172A"),
            muted = Color.parseColor("#5B6B80"),
            accent = Color.parseColor("#0284C7"),
            onAccent = Color.parseColor("#FFFFFF"),
            divider = Color.parseColor("#1F0F172A"),
        )

        val BLACK = KbTheme(
            name = "black",
            bg = Color.parseColor("#000000"),
            bar = Color.parseColor("#0A0A0A"),
            key = Color.parseColor("#1A1A1A"),
            keyPressed = Color.parseColor("#333333"),
            action = Color.parseColor("#2A2A2A"),
            actionPressed = Color.parseColor("#3D3D3D"),
            text = Color.parseColor("#FFFFFF"),
            muted = Color.parseColor("#A3A3A3"),
            accent = Color.parseColor("#7C3AED"),
            onAccent = Color.parseColor("#FFFFFF"),
            divider = Color.parseColor("#24FFFFFF"),
        )

        fun byName(name: String?): KbTheme = if (name == "black") BLACK else SNOW
    }
}
