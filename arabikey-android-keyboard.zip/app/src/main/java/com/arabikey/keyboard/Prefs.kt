package com.arabikey.keyboard

import android.content.Context
import org.json.JSONArray

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("arabikey", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "snow") ?: "snow"
        set(v) = sp.edit().putString("theme", v).apply()

    /** 0 صغير، 1 متوسط، 2 كبير */
    var keyHeight: Int
        get() = sp.getInt("keyHeight", 1)
        set(v) = sp.edit().putInt("keyHeight", v).apply()

    var haptic: Boolean
        get() = sp.getBoolean("haptic", true)
        set(v) = sp.edit().putBoolean("haptic", v).apply()

    var sound: Boolean
        get() = sp.getBoolean("sound", false)
        set(v) = sp.edit().putBoolean("sound", v).apply()

    var lang: String
        get() = sp.getString("lang", "ar") ?: "ar"
        set(v) = sp.edit().putString("lang", v).apply()

    fun clips(): List<String> {
        val raw = sp.getString("clips", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveClips(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString("clips", arr.toString()).apply()
    }
}
