package com.arabikey.keyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private var t: KbTheme = KbTheme.SNOW

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun keyboardEnabled(): Boolean {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun keyboardSelected(): Boolean {
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        return cur.startsWith("$packageName/")
    }

    private fun build() {
        t = KbTheme.byName(prefs.theme)
        window.statusBarColor = t.bg
        window.navigationBarColor = t.bg
        val light = if (t.name == "snow") {
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        } else {
            0
        }
        window.decorView.systemUiVisibility = light

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(t.bg)
        scroll.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(44), dp(20), dp(40))
        scroll.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        col.addView(label("كيبورد ذكي", 28f, true, t.text))
        col.addView(label("لوحة مفاتيح عربية حقيقية تعمل في كل التطبيقات", 14f, false, t.muted))

        // الخطوة 1
        val enabled = keyboardEnabled()
        col.addView(
            card(
                "١) تفعيل الكيبورد",
                if (enabled) "✅ مفعّل" else "غير مفعّل بعد",
            ) { box ->
                box.addView(button("فتح إعدادات لوحات المفاتيح", !enabled) {
                    startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                })
            },
        )

        // الخطوة 2
        val selected = keyboardSelected()
        col.addView(
            card(
                "٢) اختيار الكيبورد",
                if (selected) "✅ هو الكيبورد الحالي" else "اختره من القائمة لتبدأ الكتابة به",
            ) { box ->
                box.addView(button("اختيار الكيبورد", enabled && !selected) {
                    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showInputMethodPicker()
                })
            },
        )

        // المظهر
        col.addView(
            card("المظهر", "ثيم أبيض ثلجي أو ثيم أسود") { box ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.addView(optionButton("أبيض ثلجي ❄️", prefs.theme == "snow") {
                    prefs.theme = "snow"
                    build()
                }, weighted())
                row.addView(optionButton("أسود 🌑", prefs.theme == "black") {
                    prefs.theme = "black"
                    build()
                }, weighted())
                box.addView(row)
            },
        )

        // حجم الأزرار
        col.addView(
            card("حجم الأزرار", "اختر راحة الكتابة") { box ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                listOf("صغير", "متوسط", "كبير").forEachIndexed { i, name ->
                    row.addView(optionButton(name, prefs.keyHeight == i) {
                        prefs.keyHeight = i
                        build()
                    }, weighted())
                }
                box.addView(row)
            },
        )

        // التفاعل
        col.addView(
            card("التفاعل", "") { box ->
                val s1 = Switch(this)
                s1.text = "اهتزاز خفيف مع الأزرار"
                s1.setTextColor(t.text)
                s1.isChecked = prefs.haptic
                s1.setOnCheckedChangeListener { _, c -> prefs.haptic = c }
                box.addView(s1, LinearLayout.LayoutParams(MATCH, dp(48)))
                val s2 = Switch(this)
                s2.text = "صوت النقر"
                s2.setTextColor(t.text)
                s2.isChecked = prefs.sound
                s2.setOnCheckedChangeListener { _, c -> prefs.sound = c }
                box.addView(s2, LinearLayout.LayoutParams(MATCH, dp(48)))
            },
        )

        // تجربة
        col.addView(
            card("جرّب الكتابة", "اضغط في الحقل بعد اختيار الكيبورد") { box ->
                val et = EditText(this)
                et.hint = "اكتب هنا..."
                et.setTextColor(t.text)
                et.setHintTextColor(t.muted)
                et.minLines = 3
                et.gravity = Gravity.TOP or Gravity.START
                et.background = rounded(t.bg)
                et.setPadding(dp(12), dp(12), dp(12), dp(12))
                box.addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
            },
        )

        setContentView(scroll)
    }

    // ---------------------------------------------------------------- عناصر مساعدة

    private fun rounded(fill: Int, stroke: Int = t.divider): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(12).toFloat()
        g.setColor(fill)
        g.setStroke(dp(1), stroke)
        return g
    }

    private fun label(text: String, size: Float, bold: Boolean, color: Int): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(color)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.gravity = Gravity.START
        tv.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) }
        return tv
    }

    private fun card(title: String, subtitle: String, content: (LinearLayout) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = rounded(t.bar)
        box.setPadding(dp(16), dp(14), dp(16), dp(14))
        box.addView(label(title, 17f, true, t.text))
        if (subtitle.isNotEmpty()) box.addView(label(subtitle, 13f, false, t.muted))
        content(box)
        box.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) }
        return box
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(if (primary) t.onAccent else t.text)
        tv.background = rounded(if (primary) t.accent else t.action)
        tv.setOnClickListener { onClick() }
        tv.layoutParams = LinearLayout.LayoutParams(MATCH, dp(46)).apply { topMargin = dp(8) }
        return tv
    }

    private fun optionButton(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.setTextColor(if (selected) t.onAccent else t.text)
        tv.background = rounded(if (selected) t.accent else t.action)
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun weighted(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, dp(46), 1f).apply {
            topMargin = dp(8)
            marginStart = dp(4)
            marginEnd = dp(4)
        }
}
