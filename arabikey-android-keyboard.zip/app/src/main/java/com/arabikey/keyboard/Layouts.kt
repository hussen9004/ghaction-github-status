package com.arabikey.keyboard

enum class Page { AR, AR_SHIFT, EN, EN_SHIFT, SYM, SYM2, EMOJI, CLIP }

enum class KType { CHAR, SHIFT, BACK, ENTER, SPACE, SYM, ABC, EMOJI, LANG }

data class Key(
    val label: String,
    val type: KType = KType.CHAR,
    val out: String = label,
    val weight: Float = 1f,
)

object Layouts {
    private fun chars(s: String): List<Key> =
        s.split(" ").filter { it.isNotEmpty() }.map { Key(it) }

    /** علامة تشكيل تُعرض فوق دائرة منقطة. */
    private fun mark(m: String) = Key("\u25CC" + m, KType.CHAR, m)

    private fun bottom(enter: String, spaceLabel: String, comma: String): List<Key> = listOf(
        Key("123", KType.SYM, weight = 1.4f),
        Key("😊", KType.EMOJI),
        Key("🌐", KType.LANG),
        Key(spaceLabel, KType.SPACE, " ", 4f),
        Key(comma),
        Key("."),
        Key(enter, KType.ENTER, weight = 1.4f),
    )

    private fun symBottom(enter: String, abc: String): List<Key> = listOf(
        Key(abc, KType.ABC, weight = 1.4f),
        Key("😊", KType.EMOJI),
        Key(" ", KType.SPACE, " ", 4f),
        Key("،"),
        Key("."),
        Key(enter, KType.ENTER, weight = 1.4f),
    )

    private val back = Key("⌫", KType.BACK, weight = 1.5f)
    private fun shift(label: String = "⇧") = Key(label, KType.SHIFT, weight = 1.5f)

    fun rows(page: Page, enter: String): List<List<Key>> = when (page) {
        Page.AR -> listOf(
            chars("ض ص ث ق ف غ ع ه خ ح ج د"),
            chars("ش س ي ب ل ا ت ن م ك ط ذ"),
            listOf(shift()) + chars("ئ ء ؤ ر لا ى ة و ز ظ") + back,
            bottom(enter, "العربية", "،"),
        )
        Page.AR_SHIFT -> listOf(
            listOf("\u064E", "\u064B", "\u064F", "\u064C", "\u0650", "\u064D", "\u0651", "\u0652")
                .map { mark(it) } + chars("ـ ؛ ؟ !"),
            chars("أ إ آ ٱ ؤ ئ ء ة ى ، : \""),
            listOf(shift()) + chars("( ) [ ] { } / - _") + back,
            bottom(enter, "العربية", "،"),
        )
        Page.EN -> listOf(
            chars("q w e r t y u i o p"),
            chars("a s d f g h j k l"),
            listOf(shift()) + chars("z x c v b n m") + back,
            bottom(enter, "English", ","),
        )
        Page.EN_SHIFT -> listOf(
            chars("Q W E R T Y U I O P"),
            chars("A S D F G H J K L"),
            listOf(shift()) + chars("Z X C V B N M") + back,
            bottom(enter, "English", ","),
        )
        Page.SYM -> listOf(
            chars("1 2 3 4 5 6 7 8 9 0"),
            chars("@ # $ % & - + ( ) /"),
            listOf(shift("=\\<")) + chars("* \" ' : ; ! ? ، ؟") + back,
            symBottom(enter, "ABC"),
        )
        Page.SYM2 -> listOf(
            chars("١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩ ٠"),
            chars("€ £ ¥ ﷼ ° • ± × ÷ ="),
            listOf(shift("123")) + chars("~ ` | ^ < > { } [ ]") + back,
            symBottom(enter, "ABC"),
        )
        else -> emptyList()
    }

    val EMOJIS: List<String> = (
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 " +
            "😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 " +
            "😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 😈 💀 👻 👽 🤖 💩 🙈 🙉 🙊 👍 👎 👌 ✌️ 🤞 🤟 🤘 👏 🙌 🙏 " +
            "💪 👋 🤝 ☝️ 👆 👇 👉 👈 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💞 💓 💗 💖 💘 💯 🔥 ✨ ⭐ 🌟 🎉 🎊 🎁 " +
            "☕ 🍵 🍽️ 🍕 🍔 🍟 🍰 🎂 🍫 🍎 🍉 🌹 🌸 🌴 ☀️ 🌙 ⚡ ☔ 🌈 🐱 🐶 🐎 🐪 🦅 🚗 ✈️ 🏠 📱 💻 📷 🎧 🎮 ⚽ 🕌 🕋 📿 🤲 ✅ ❌ ⚠️ ❓ ❗"
        ).split(" ").filter { it.isNotEmpty() }
}
