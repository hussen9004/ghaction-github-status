package com.arabikey.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ArabiKeyService : InputMethodService() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private var kb: KbTheme = KbTheme.SNOW
    private var root: LinearLayout? = null
    private var keysHost: LinearLayout? = null

    private var page = Page.AR
    private var lang = "ar"
    private var shiftState = 0 // 0 مطفأ، 1 لمرة واحدة، 2 قفل (للإنجليزية)
    private var haptic = true
    private var sound = false
    private var suggestOn = true

    private var suggestionViews: List<TextView> = emptyList()
    private var suggestions: List<String> = listOf("", "", "")

    private val handler = Handler(Looper.getMainLooper())
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    private val repeatBack = object : Runnable {
        override fun run() {
            backspace()
            handler.postDelayed(this, 45)
        }
    }

    // ---------------------------------------------------------------- دورة الحياة

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        kb = KbTheme.byName(prefs.theme)
        lang = prefs.lang
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val l = ClipboardManager.OnPrimaryClipChangedListener { captureClip(cm) }
            clipListener = l
            cm.addPrimaryClipChangedListener(l)
        } catch (e: Exception) {
            // الحافظة اختيارية
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipListener?.let { cm.removePrimaryClipChangedListener(it) }
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root = r
        buildUi()
        return r
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lang = prefs.lang
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        suggestOn = true
        page = if (lang == "ar") Page.AR else Page.EN
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE || cls == InputType.TYPE_CLASS_DATETIME) {
            page = Page.SYM
            suggestOn = false
        } else if (cls == InputType.TYPE_CLASS_TEXT) {
            val latinOnly = variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
                variation == InputType.TYPE_TEXT_VARIATION_URI ||
                variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            if (latinOnly) {
                lang = "en"
                page = Page.EN
            }
            if (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            ) {
                suggestOn = false
            }
        }
        shiftState = 0
        buildUi() // يلتقط تغييرات الثيم والحجم من الإعدادات
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(repeatBack)
        super.onFinishInputView(finishingInput)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int,
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateSuggestions()
    }

    // ---------------------------------------------------------------- بناء الواجهة

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun keyHeightDp(): Int {
        val base = when (prefs.keyHeight) {
            0 -> 44
            2 -> 58
            else -> 51
        }
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        return if (landscape) (base * 0.78f).toInt() else base
    }

    private fun rowHeight(): Int = dp(keyHeightDp()) + dp(6)

    private fun buildUi() {
        val r = root ?: return
        kb = KbTheme.byName(prefs.theme)
        haptic = prefs.haptic
        sound = prefs.sound
        r.removeAllViews()
        r.setBackgroundColor(kb.bg)
        r.addView(buildBar(), LinearLayout.LayoutParams(MATCH, dp(44)))
        val host = LinearLayout(this)
        host.orientation = LinearLayout.VERTICAL
        keysHost = host
        r.addView(host, LinearLayout.LayoutParams(MATCH, WRAP))
        applyWindowColors()
        renderPage()
    }

    private fun applyWindowColors() {
        try {
            val w = window?.window ?: return
            w.navigationBarColor = kb.bg
            if (Build.VERSION.SDK_INT >= 26) {
                val flags = w.decorView.systemUiVisibility
                w.decorView.systemUiVisibility =
                    if (kb.name == "snow") flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    else flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
        } catch (e: Exception) {
        }
    }

    private fun mainPage(): Page = if (lang == "ar") Page.AR else Page.EN

    private fun buildBar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(kb.bar)

        bar.addView(iconButton("⚙️") { openSettings() })
        bar.addView(iconButton("📋") {
            page = if (page == Page.CLIP) mainPage() else Page.CLIP
            shiftState = 0
            renderPage()
        })
        bar.addView(iconButton("🌓") {
            prefs.theme = if (prefs.theme == "snow") "black" else "snow"
            handler.post { buildUi() }
        })

        val views = ArrayList<TextView>()
        for (i in 0 until 3) {
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            tv.setTextColor(kb.text)
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setOnClickListener { applySuggestion(i) }
            bar.addView(tv, LinearLayout.LayoutParams(0, MATCH, 1f))
            views.add(tv)
            if (i < 2) {
                val d = View(this)
                d.setBackgroundColor(kb.divider)
                bar.addView(d, LinearLayout.LayoutParams(dp(1), dp(20)))
            }
        }
        suggestionViews = views
        return bar
    }

    private fun iconButton(text: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        tv.setTextColor(kb.text)
        tv.layoutParams = LinearLayout.LayoutParams(dp(40), MATCH)
        tv.setOnClickListener {
            feedback(it)
            onClick()
        }
        return tv
    }

    private fun renderPage() {
        val host = keysHost ?: return
        host.removeAllViews()
        when (page) {
            Page.EMOJI -> host.addView(buildEmojiPanel())
            Page.CLIP -> host.addView(buildClipPanel())
            else -> for (row in Layouts.rows(page, enterLabel())) host.addView(buildRow(row))
        }
        updateSuggestions()
    }

    private fun renderLater() {
        handler.post { renderPage() }
    }

    private fun buildRow(keys: List<Key>): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH, rowHeight())
        row.setPadding(dp(2), 0, dp(2), 0)
        for (k in keys) {
            val lp = LinearLayout.LayoutParams(0, MATCH, k.weight)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            row.addView(buildKey(k), lp)
        }
        return row
    }

    private fun shape(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(8).toFloat()
        g.setColor(color)
        g.setStroke(dp(1), kb.divider)
        return g
    }

    private fun keyBg(fill: Int, pressed: Int): StateListDrawable {
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), shape(pressed))
        sl.addState(intArrayOf(), shape(fill))
        return sl
    }

    private fun darken(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.82f).toInt(),
        (Color.green(c) * 0.82f).toInt(),
        (Color.blue(c) * 0.82f).toInt(),
    )

    private fun buildKey(k: Key): TextView {
        val tv = TextView(this)
        val special = k.type != KType.CHAR && k.type != KType.SPACE
        var fill = if (special) kb.action else kb.key
        var pressedFill = if (special) kb.actionPressed else kb.keyPressed
        var textColor = kb.text
        var label = k.label
        var size = if (special) 16f else 21f

        when (k.type) {
            KType.ENTER -> {
                fill = kb.accent
                pressedFill = darken(kb.accent)
                textColor = kb.onAccent
                size = 20f
            }
            KType.SHIFT -> {
                if (page == Page.AR_SHIFT || page == Page.EN_SHIFT) {
                    textColor = kb.accent
                    if (page == Page.EN_SHIFT && shiftState == 2) label = "⇪"
                }
            }
            KType.SPACE -> {
                size = 13f
                textColor = kb.muted
            }
            else -> {}
        }

        tv.text = label
        tv.gravity = Gravity.CENTER
        tv.isSingleLine = true
        tv.setTextColor(textColor)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        if (special) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.background = keyBg(fill, pressedFill)

        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    feedback(v)
                    onKeyDown(k)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    if (k.type == KType.BACK) handler.removeCallbacks(repeatBack)
                }
            }
            true
        }
        return tv
    }

    private fun bottomBarKeys(): List<Key> = listOf(
        Key(if (lang == "ar") "أبج" else "ABC", KType.ABC, weight = 1.6f),
        Key(" ", KType.SPACE, " ", 4f),
        Key("⌫", KType.BACK, weight = 1.6f),
    )

    private fun buildEmojiPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (chunk in Layouts.EMOJIS.chunked(8)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (e in chunk) {
                val tv = TextView(this)
                tv.text = e
                tv.gravity = Gravity.CENTER
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                tv.setOnClickListener {
                    feedback(it)
                    commit(e)
                }
                row.addView(tv, LinearLayout.LayoutParams(0, dp(46), 1f))
            }
            for (i in chunk.size until 8) row.addView(View(this), LinearLayout.LayoutParams(0, dp(46), 1f))
            grid.addView(row)
        }
        scroll.addView(grid)
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, rowHeight() * 3))
        col.addView(buildRow(bottomBarKeys()))
        return col
    }

    private fun buildClipPanel(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12), 0, dp(12), 0)
        val title = TextView(this)
        title.text = "📋 الحافظة"
        title.setTextColor(kb.text)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        title.setTypeface(title.typeface, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val clear = TextView(this)
        clear.text = "مسح الكل"
        clear.setTextColor(kb.accent)
        clear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        clear.setPadding(dp(8), dp(8), dp(8), dp(8))
        clear.setOnClickListener {
            prefs.saveClips(emptyList())
            renderPage()
        }
        header.addView(clear)
        col.addView(header, LinearLayout.LayoutParams(MATCH, dp(40)))

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val items = prefs.clips()
        if (items.isEmpty()) {
            val empty = TextView(this)
            empty.text = "لا توجد عناصر منسوخة بعد. انسخ نصًا وسيظهر هنا."
            empty.setTextColor(kb.muted)
            empty.gravity = Gravity.CENTER
            empty.setPadding(dp(16), dp(24), dp(16), dp(24))
            list.addView(empty, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        items.forEachIndexed { index, text ->
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER_VERTICAL
            line.background = shape(kb.key)
            val t = TextView(this)
            t.text = text.replace("\n", " ")
            t.setTextColor(kb.text)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER_VERTICAL or Gravity.START
            t.setPadding(dp(12), 0, dp(8), 0)
            t.setOnClickListener {
                feedback(it)
                commit(text)
            }
            line.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
            val x = TextView(this)
            x.text = "✕"
            x.gravity = Gravity.CENTER
            x.setTextColor(kb.muted)
            x.setOnClickListener {
                val all = prefs.clips().toMutableList()
                if (index < all.size) all.removeAt(index)
                prefs.saveClips(all)
                renderPage()
            }
            line.addView(x, LinearLayout.LayoutParams(dp(40), MATCH))
            val lp = LinearLayout.LayoutParams(MATCH, dp(42))
            lp.setMargins(dp(6), dp(3), dp(6), dp(3))
            list.addView(line, lp)
        }
        scroll.addView(list)
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, rowHeight() * 3 - dp(40)))
        col.addView(buildRow(bottomBarKeys()))
        return col
    }

    // ---------------------------------------------------------------- معالجة المفاتيح

    private fun onKeyDown(k: Key) {
        when (k.type) {
            KType.CHAR -> {
                commit(k.out)
                if (page == Page.EN_SHIFT && shiftState == 1) {
                    shiftState = 0
                    page = Page.EN
                    renderLater()
                }
            }
            KType.SPACE -> commit(" ")
            KType.BACK -> {
                backspace()
                handler.postDelayed(repeatBack, 400)
            }
            KType.ENTER -> enter()
            KType.SHIFT -> {
                toggleShift()
                renderLater()
            }
            KType.SYM -> {
                page = Page.SYM
                renderLater()
            }
            KType.ABC -> {
                shiftState = 0
                page = mainPage()
                renderLater()
            }
            KType.EMOJI -> {
                page = Page.EMOJI
                renderLater()
            }
            KType.LANG -> {
                lang = if (lang == "ar") "en" else "ar"
                prefs.lang = lang
                shiftState = 0
                page = mainPage()
                renderLater()
            }
        }
    }

    private fun toggleShift() {
        when (page) {
            Page.AR -> page = Page.AR_SHIFT
            Page.AR_SHIFT -> page = Page.AR
            Page.EN -> {
                shiftState = 1
                page = Page.EN_SHIFT
            }
            Page.EN_SHIFT -> {
                if (shiftState == 1) {
                    shiftState = 2
                } else {
                    shiftState = 0
                    page = Page.EN
                }
            }
            Page.SYM -> page = Page.SYM2
            Page.SYM2 -> page = Page.SYM
            else -> {}
        }
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
        updateSuggestions()
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        updateSuggestions()
    }

    private fun enter() {
        val info = currentInputEditorInfo
        val opts = info?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun enterLabel(): String {
        val info = currentInputEditorInfo ?: return "↵"
        val opts = info.imeOptions
        if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "↵"
        return when (opts and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_NEXT -> "⇥"
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "↵"
        }
    }

    private fun feedback(v: View) {
        if (haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (sound) {
            try {
                (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                    .playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
            } catch (e: Exception) {
            }
        }
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        requestHideSelf(0)
    }

    // ---------------------------------------------------------------- الاقتراحات والحافظة

    private fun trailingWord(s: String): String {
        var i = s.length
        while (i > 0) {
            val ch = s[i - 1]
            if (Character.isLetter(ch) || Character.getType(ch) == Character.NON_SPACING_MARK.toInt()) i-- else break
        }
        return s.substring(i)
    }

    private fun updateSuggestions() {
        if (suggestionViews.isEmpty()) return
        if (!suggestOn) {
            suggestions = listOf("", "", "")
        } else {
            val before = currentInputConnection?.getTextBeforeCursor(40, 0)?.toString() ?: ""
            val word = trailingWord(before)
            val rest = before.substring(0, before.length - word.length).trim()
            val prev = trailingWord(rest)
            val arabic = when (page) {
                Page.AR, Page.AR_SHIFT -> true
                Page.EN, Page.EN_SHIFT -> false
                else -> lang == "ar"
            }
            suggestions = Words.suggest(word, prev, arabic)
        }
        for (i in 0 until 3) suggestionViews[i].text = suggestions[i]
    }

    private fun applySuggestion(i: Int) {
        val s = suggestions.getOrNull(i) ?: return
        if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
        val word = trailingWord(before)
        ic.beginBatchEdit()
        if (word.isNotEmpty()) ic.deleteSurroundingText(word.length, 0)
        ic.commitText("$s ", 1)
        ic.endBatchEdit()
        updateSuggestions()
    }

    private fun captureClip(cm: ClipboardManager) {
        try {
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val text = clip.getItemAt(0).coerceToText(this)?.toString()?.trim() ?: return
            if (text.isEmpty() || text.length > 2000) return
            val list = prefs.clips().toMutableList()
            list.remove(text)
            list.add(0, text)
            prefs.saveClips(list.take(20))
        } catch (e: Exception) {
        }
    }
}
